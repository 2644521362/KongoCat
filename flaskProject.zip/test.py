from Works.works_method import AudioWorkMethod, WorksMethod
from Users.users_method import UserMethod
if __name__ == '__main__':
    # audiofile = r'C:\Users\16025\Desktop\port\abc.pcm'
    # result = AudioWorkMethod.translate_work(audiofile)
    # print(result)
    path = r"C:\Users\16025\Desktop\port"
    audioName = r"\mintest3.m4a"
    userId = 2
    filePath = path + audioName
    print(filePath)
    s = list(filePath)
    length = len(s)
    s[length - 1] = 'm'
    s[length - 2] = 'c'
    s[length - 3] = 'p'
    new_path = ''.join(s)
    print(new_path)
    result = WorksMethod.publish_public_work(audioName, filePath, userId)
    score = thisAudioId2Score = WorksMethod.make_comment(str(result))
    # result = WorksMethod.publish_public_work(audioName, filePath, userId)  # save id
    # text = AudioWorkMethod.translate_work(filePath)
    print(result)
    print(score)